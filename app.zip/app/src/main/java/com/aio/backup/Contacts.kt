package com.aio.backup

import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.provider.ContactsContract
import java.io.ByteArrayOutputStream

data class ContactItem(
    val id: Long,
    val name: String,
    val phones: List<String>,
    val emails: List<String>
)

data class ParsedContact(
    val name: String,
    val phones: List<String>,
    val emails: List<String>
)

/** Keeps the last 10 digits so +92300..., 0300... and 300... all match. */
fun normalizePhone(p: String): String {
    val d = p.filter { it.isDigit() }
    return if (d.length > 10) d.takeLast(10) else d
}

private fun phoneKey(p: String): String = normalizePhone(p).ifEmpty { p }

object ContactsRepo {

    fun readAll(ctx: Context): List<ContactItem> {
        val cr = ctx.contentResolver

        val names = LinkedHashMap<Long, String>()
        cr.query(
            ContactsContract.Contacts.CONTENT_URI,
            arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME),
            null,
            null,
            ContactsContract.Contacts.DISPLAY_NAME + " COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                names[c.getLong(0)] = c.getString(1) ?: ""
            }
        }

        val phones = HashMap<Long, MutableList<String>>()
        cr.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val n = (c.getString(1) ?: "").trim()
                if (n.isNotEmpty()) {
                    val list = phones.getOrPut(c.getLong(0)) { mutableListOf() }
                    if (!list.contains(n)) list.add(n)
                }
            }
        }

        val emails = HashMap<Long, MutableList<String>>()
        cr.query(
            ContactsContract.CommonDataKinds.Email.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Email.CONTACT_ID,
                ContactsContract.CommonDataKinds.Email.ADDRESS
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val a = (c.getString(1) ?: "").trim()
                if (a.isNotEmpty()) {
                    val list = emails.getOrPut(c.getLong(0)) { mutableListOf() }
                    if (!list.contains(a)) list.add(a)
                }
            }
        }

        return names.map { (id, name) ->
            ContactItem(id, name, phones[id].orEmpty(), emails[id].orEmpty())
        }.filter { it.name.isNotBlank() || it.phones.isNotEmpty() || it.emails.isNotEmpty() }
    }

    /** Adds contacts to the phone (device storage). Returns how many were added. */
    fun insertContacts(ctx: Context, list: List<ParsedContact>): Int {
        var added = 0
        for (chunk in list.chunked(40)) {
            val ops = ArrayList<ContentProviderOperation>()
            for (c in chunk) {
                val rawIndex = ops.size
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build()
                )
                if (c.name.isNotBlank()) {
                    ops.add(
                        ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawIndex)
                            .withValue(
                                ContactsContract.Data.MIMETYPE,
                                ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                            )
                            .withValue(
                                ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                                c.name
                            )
                            .build()
                    )
                }
                for (p in c.phones) {
                    ops.add(
                        ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawIndex)
                            .withValue(
                                ContactsContract.Data.MIMETYPE,
                                ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                            )
                            .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, p)
                            .withValue(
                                ContactsContract.CommonDataKinds.Phone.TYPE,
                                ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                            )
                            .build()
                    )
                }
                for (e in c.emails) {
                    ops.add(
                        ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, rawIndex)
                            .withValue(
                                ContactsContract.Data.MIMETYPE,
                                ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE
                            )
                            .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, e)
                            .withValue(
                                ContactsContract.CommonDataKinds.Email.TYPE,
                                ContactsContract.CommonDataKinds.Email.TYPE_OTHER
                            )
                            .build()
                    )
                }
            }
            try {
                ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
                added += chunk.size
            } catch (e: Exception) {
                // skip this chunk and continue with the rest
            }
        }
        return added
    }

    /** Groups of contacts that look like the same person. */
    fun findDuplicateGroups(all: List<ContactItem>, byName: Boolean): List<List<ContactItem>> {
        val parent = IntArray(all.size) { it }

        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) {
                parent[r] = parent[parent[r]]
                r = parent[r]
            }
            return r
        }

        fun union(a: Int, b: Int) {
            val ra = find(a)
            val rb = find(b)
            if (ra != rb) parent[ra] = rb
        }

        val firstSeen = HashMap<String, Int>()
        all.forEachIndexed { i, c ->
            val keys = HashSet<String>()
            c.phones.map { normalizePhone(it) }
                .filter { it.length >= 6 }
                .forEach { keys.add("p:$it") }
            c.emails.forEach { keys.add("e:" + it.lowercase()) }
            if (byName) {
                val nm = c.name.trim().lowercase()
                if (nm.isNotEmpty()) keys.add("n:$nm")
            }
            for (k in keys) {
                val j = firstSeen[k]
                if (j == null) firstSeen[k] = i else union(i, j)
            }
        }

        val groups = HashMap<Int, MutableList<ContactItem>>()
        all.forEachIndexed { i, c ->
            groups.getOrPut(find(i)) { mutableListOf() }.add(c)
        }
        return groups.values.filter { it.size > 1 }
    }

    private fun bestRawContactId(ctx: Context, contactId: Long): Long? {
        var fallback: Long? = null
        ctx.contentResolver.query(
            ContactsContract.RawContacts.CONTENT_URI,
            arrayOf(ContactsContract.RawContacts._ID, ContactsContract.RawContacts.ACCOUNT_TYPE),
            ContactsContract.RawContacts.CONTACT_ID + "=? AND " +
                ContactsContract.RawContacts.DELETED + "=0",
            arrayOf(contactId.toString()),
            null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val type = (c.getString(1) ?: "").lowercase()
                if (fallback == null) fallback = id
                if (!type.contains("whatsapp") && !type.contains("telegram")) return id
            }
        }
        return fallback
    }

    /**
     * Merges one group: numbers/emails of the extra copies are added to the best
     * contact, then the extra copies are deleted. Returns false if nothing was deleted.
     */
    fun mergeGroup(ctx: Context, group: List<ContactItem>): Boolean {
        val keeper = group.maxByOrNull {
            it.phones.size + it.emails.size + (if (it.name.isNotBlank()) 1 else 0)
        } ?: return false
        val others = group.filter { it.id != keeper.id }
        if (others.isEmpty()) return false

        val havePhones = keeper.phones.map { phoneKey(it) }.toMutableSet()
        val haveEmails = keeper.emails.map { it.lowercase() }.toMutableSet()
        val newPhones = mutableListOf<String>()
        val newEmails = mutableListOf<String>()
        for (o in others) {
            for (p in o.phones) if (havePhones.add(phoneKey(p))) newPhones.add(p)
            for (e in o.emails) if (haveEmails.add(e.lowercase())) newEmails.add(e)
        }

        if (newPhones.isNotEmpty() || newEmails.isNotEmpty()) {
            val raw = bestRawContactId(ctx, keeper.id) ?: return false
            val ops = ArrayList<ContentProviderOperation>()
            for (p in newPhones) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValue(ContactsContract.Data.RAW_CONTACT_ID, raw)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, p)
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        .build()
                )
            }
            for (e in newEmails) {
                ops.add(
                    ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValue(ContactsContract.Data.RAW_CONTACT_ID, raw)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE
                        )
                        .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, e)
                        .withValue(
                            ContactsContract.CommonDataKinds.Email.TYPE,
                            ContactsContract.CommonDataKinds.Email.TYPE_OTHER
                        )
                        .build()
                )
            }
            try {
                ctx.contentResolver.applyBatch(ContactsContract.AUTHORITY, ops)
            } catch (e: Exception) {
                return false // do not delete anything if we could not save the merged data
            }
        }

        for (o in others) {
            ctx.contentResolver.delete(
                ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, o.id),
                null,
                null
            )
        }
        return true
    }
}

object Vcf {

    private fun esc(s: String): String = s
        .replace("\\", "\\\\")
        .replace(";", "\\;")
        .replace(",", "\\,")
        .replace("\r\n", "\\n")
        .replace("\n", "\\n")

    private fun unesc(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '\\' && i + 1 < s.length) {
                val n = s[i + 1]
                sb.append(if (n == 'n' || n == 'N') '\n' else n)
                i += 2
            } else {
                sb.append(ch)
                i++
            }
        }
        return sb.toString()
    }

    private fun decodeQp(s: String): String {
        val out = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '=' && i + 2 < s.length) {
                val v = s.substring(i + 1, i + 3).toIntOrNull(16)
                if (v != null) {
                    out.write(v)
                    i += 3
                    continue
                }
            }
            out.write(ch.toString().toByteArray(Charsets.UTF_8))
            i++
        }
        return String(out.toByteArray(), Charsets.UTF_8)
    }

    fun write(list: List<ContactItem>): String {
        val sb = StringBuilder()
        for (c in list) {
            sb.append("BEGIN:VCARD\r\n")
            sb.append("VERSION:3.0\r\n")
            sb.append("N:;").append(esc(c.name)).append(";;;\r\n")
            sb.append("FN:").append(esc(c.name)).append("\r\n")
            for (p in c.phones) sb.append("TEL;TYPE=CELL:").append(p).append("\r\n")
            for (e in c.emails) sb.append("EMAIL;TYPE=INTERNET:").append(e).append("\r\n")
            sb.append("END:VCARD\r\n")
        }
        return sb.toString()
    }

    fun parse(text: String): List<ParsedContact> {
        val raw = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")

        // unfold wrapped lines
        val lines = ArrayList<String>()
        for (l in raw) {
            val last = lines.lastOrNull()
            if (last != null && (l.startsWith(" ") || l.startsWith("\t"))) {
                lines[lines.size - 1] = last + l.substring(1)
            } else if (last != null && last.endsWith("=") &&
                last.uppercase().contains("QUOTED-PRINTABLE")
            ) {
                lines[lines.size - 1] = last.dropLast(1) + l
            } else {
                lines.add(l)
            }
        }

        val out = ArrayList<ParsedContact>()
        var fullName = ""
        var nameFromN = ""
        val phones = mutableListOf<String>()
        val emails = mutableListOf<String>()
        var inCard = false

        for (line in lines) {
            val t = line.trim()
            if (t.equals("BEGIN:VCARD", ignoreCase = true)) {
                inCard = true
                fullName = ""
                nameFromN = ""
                phones.clear()
                emails.clear()
                continue
            }
            if (t.equals("END:VCARD", ignoreCase = true)) {
                if (inCard) {
                    val nm = fullName.ifBlank { nameFromN }.trim()
                    if (nm.isNotEmpty() || phones.isNotEmpty() || emails.isNotEmpty()) {
                        out.add(ParsedContact(nm, phones.toList(), emails.toList()))
                    }
                }
                inCard = false
                continue
            }
            if (!inCard) continue

            val idx = line.indexOf(':')
            if (idx <= 0) continue
            val head = line.substring(0, idx)
            var value = line.substring(idx + 1)
            val prop = head.split(";")[0].substringAfterLast('.').uppercase()
            if (head.uppercase().contains("QUOTED-PRINTABLE")) value = decodeQp(value)

            when (prop) {
                "FN" -> fullName = unesc(value).trim()
                "N" -> {
                    val p = value.split(";")
                    val family = unesc(p.getOrElse(0) { "" }).trim()
                    val given = unesc(p.getOrElse(1) { "" }).trim()
                    nameFromN = (given + " " + family).trim()
                }
                "TEL" -> {
                    val v = value.trim()
                    if (v.isNotEmpty() && !phones.contains(v)) phones.add(v)
                }
                "EMAIL" -> {
                    val v = value.trim()
                    if (v.isNotEmpty() && !emails.contains(v)) emails.add(v)
                }
            }
        }
        return out
    }
}
