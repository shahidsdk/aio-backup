package com.aio.backup

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupStore {

    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, "backups").apply { mkdirs() }
    }

    fun stamp(): String =
        SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())

    /** Reads all contacts and writes a .vcf file inside the app's backup folder. */
    fun createLocalBackup(ctx: Context, prefix: String): File {
        val contacts = ContactsRepo.readAll(ctx)
        val f = File(dir(ctx), "${prefix}_${stamp()}_${contacts.size}contacts.vcf")
        f.writeText(Vcf.write(contacts), Charsets.UTF_8)
        return f
    }

    fun list(ctx: Context): List<File> {
        val files = dir(ctx).listFiles()?.filter { it.isFile && it.extension == "vcf" }
            ?: emptyList()
        return files.sortedByDescending { it.lastModified() }
    }

    fun prune(ctx: Context, prefix: String, keep: Int) {
        list(ctx).filter { it.name.startsWith(prefix + "_") }.drop(keep).forEach { it.delete() }
    }

    fun share(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/x-vcard"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "AIO Backup - " + file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Send backup (Gmail, Drive, ...)"))
    }
}
