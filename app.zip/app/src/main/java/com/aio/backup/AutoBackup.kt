package com.aio.backup

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

class AutoBackupWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return Result.success()
        }
        return try {
            BackupStore.createLocalBackup(ctx, "auto")
            BackupStore.prune(ctx, "auto", 10)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object AutoBackup {
    private const val WORK_NAME = "aio_auto_backup"
    private const val PREFS = "aio_prefs"
    private const val KEY_MODE = "auto_mode"

    /** 0 = off, 1 = daily, 2 = weekly */
    fun getMode(ctx: Context): Int =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_MODE, 0)

    fun setMode(ctx: Context, mode: Int) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putInt(KEY_MODE, mode).apply()
        val wm = WorkManager.getInstance(ctx)
        if (mode == 0) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        val days = if (mode == 1) 1L else 7L
        val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(days, TimeUnit.DAYS).build()
        wm.enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
