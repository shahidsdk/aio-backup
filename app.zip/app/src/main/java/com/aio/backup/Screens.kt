@file:OptIn(ExperimentalMaterial3Api::class)

package com.aio.backup

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Pending(val label: String, val total: Int, val fresh: List<ParsedContact>)

// ---------------------------------------------------------------- BACKUP

@Composable
fun BackupScreen(snack: SnackbarHostState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var count by remember { mutableStateOf<Int?>(null) }
    var busy by remember { mutableStateOf(false) }
    var autoMode by remember { mutableIntStateOf(AutoBackup.getMode(ctx)) }

    LaunchedEffect(Unit) {
        count = withContext(Dispatchers.IO) {
            try { ContactsRepo.readAll(ctx).size } catch (e: Exception) { 0 }
        }
    }

    // Lets the user pick ANY place: phone storage, SD card, USB drive, Google Drive...
    val saveLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/x-vcard")
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                val n = withContext(Dispatchers.IO) {
                    try {
                        val list = ContactsRepo.readAll(ctx)
                        ctx.contentResolver.openOutputStream(uri)?.use {
                            it.write(Vcf.write(list).toByteArray(Charsets.UTF_8))
                        }
                        list.size
                    } catch (e: Exception) {
                        -1
                    }
                }
                busy = false
                snack.showSnackbar(if (n >= 0) "$n contacts saved" else "Could not save the file")
            }
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Contacts on this phone", style = MaterialTheme.typography.labelLarge)
                Text(count?.toString() ?: "...", style = MaterialTheme.typography.headlineMedium)
            }
        }

        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())

        Button(
            onClick = { saveLauncher.launch("AIO_contacts_" + BackupStore.stamp() + ".vcf") },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Save to phone / SD card / Drive") }

        Button(
            onClick = {
                scope.launch {
                    busy = true
                    try {
                        val f = withContext(Dispatchers.IO) {
                            BackupStore.createLocalBackup(ctx, "manual")
                        }
                        BackupStore.share(ctx, f)
                    } catch (e: Exception) {
                        snack.showSnackbar("Could not share the backup")
                    }
                    busy = false
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Send by Gmail / other apps") }

        OutlinedButton(
            onClick = {
                scope.launch {
                    busy = true
                    val name = withContext(Dispatchers.IO) {
                        try { BackupStore.createLocalBackup(ctx, "manual").name } catch (e: Exception) { null }
                    }
                    busy = false
                    snack.showSnackbar(if (name != null) "Saved in app: $name" else "Backup failed")
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Quick backup inside the app") }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Auto backup", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Saves a backup inside the app automatically. The last 10 are kept.",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Off", "Daily", "Weekly").forEachIndexed { i, label ->
                        FilterChip(
                            selected = autoMode == i,
                            onClick = {
                                autoMode = i
                                AutoBackup.setMode(ctx, i)
                            },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }

        Text(
            "Note: backups kept inside the app are deleted if you uninstall the app. " +
                "For real safety, also use \"Save to phone / SD card / Drive\" or \"Send by Gmail\".",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

// ---------------------------------------------------------------- RESTORE

@Composable
fun RestoreScreen(snack: SnackbarHostState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Pending?>(null) }
    var files by remember { mutableStateOf(BackupStore.list(ctx)) }
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    fun prepare(text: String, label: String) {
        scope.launch {
            busy = true
            val p = withContext(Dispatchers.IO) {
                val parsed = Vcf.parse(text)
                val existing = ContactsRepo.readAll(ctx)
                val phoneKeys = HashSet<String>()
                val names = HashSet<String>()
                existing.forEach { e ->
                    e.phones.forEach { ph ->
                        val k = normalizePhone(ph)
                        if (k.length >= 6) phoneKeys.add(k)
                    }
                    if (e.name.isNotBlank()) names.add(e.name.trim().lowercase())
                }
                val fresh = parsed.filter { c ->
                    val keys = c.phones.map { normalizePhone(it) }.filter { it.length >= 6 }
                    if (keys.isNotEmpty()) keys.none { it in phoneKeys }
                    else c.name.trim().lowercase() !in names
                }
                Pending(label, parsed.size, fresh)
            }
            busy = false
            pending = p
        }
    }

    val openLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openInputStream(uri)
                            ?.bufferedReader(Charsets.UTF_8)
                            ?.use { it.readText() }
                    } catch (e: Exception) {
                        null
                    }
                }
                if (text == null) snack.showSnackbar("Could not read that file")
                else prepare(text, "the selected file")
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button(
            onClick = { openLauncher.launch(arrayOf("*/*")) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Choose a backup file (.vcf)") }

        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))

        Spacer(Modifier.height(16.dp))
        Text("Backups saved in the app", style = MaterialTheme.typography.titleMedium)
        if (files.isEmpty()) {
            Text(
                "No backups yet. Make one from the Backup tab.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
        LazyColumn(Modifier.weight(1f)) {
            items(files) { f ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(f.name, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            dateFormat.format(Date(f.lastModified())) + "  -  " +
                                (f.length() / 1024) + " KB",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row {
                            TextButton(onClick = {
                                scope.launch {
                                    val t = withContext(Dispatchers.IO) { f.readText() }
                                    prepare(t, f.name)
                                }
                            }) { Text("Restore") }
                            TextButton(onClick = {
                                try { BackupStore.share(ctx, f) } catch (e: Exception) { }
                            }) { Text("Share") }
                            TextButton(onClick = {
                                f.delete()
                                files = BackupStore.list(ctx)
                            }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }

    pending?.let { p ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("Restore contacts") },
            text = {
                Text(
                    "Found ${p.total} contacts in ${p.label}.\n" +
                        "${p.fresh.size} are new and will be added.\n" +
                        "${p.total - p.fresh.size} already exist and will be skipped."
                )
            },
            confirmButton = {
                TextButton(
                    enabled = p.fresh.isNotEmpty(),
                    onClick = {
                        pending = null
                        scope.launch {
                            busy = true
                            val n = withContext(Dispatchers.IO) {
                                ContactsRepo.insertContacts(ctx, p.fresh)
                            }
                            busy = false
                            snack.showSnackbar("$n contacts restored")
                        }
                    }
                ) { Text("Restore") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- DUPLICATES

@Composable
fun CleanupScreen(snack: SnackbarHostState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var byName by remember { mutableStateOf(false) }
    var groups by remember { mutableStateOf<List<List<ContactItem>>?>(null) }
    val checked = remember { mutableStateListOf<Boolean>() }
    var confirm by remember { mutableStateOf(false) }

    fun scan() {
        scope.launch {
            busy = true
            val g = withContext(Dispatchers.IO) {
                try {
                    ContactsRepo.findDuplicateGroups(ContactsRepo.readAll(ctx), byName)
                } catch (e: Exception) {
                    emptyList()
                }
            }
            checked.clear()
            g.forEach { _ -> checked.add(true) }
            groups = g
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = byName, onCheckedChange = { byName = it })
            Spacer(Modifier.width(8.dp))
            Text("Also treat the same name as a duplicate")
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { scan() },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Scan for duplicates") }

        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp))

        val g = groups
        if (g != null) {
            Spacer(Modifier.height(8.dp))
            if (g.isEmpty()) {
                Text("No duplicates found.")
            } else {
                Text(
                    "${g.size} groups found (${g.sumOf { it.size }} contacts). " +
                        "Untick any group you want to keep as it is.",
                    style = MaterialTheme.typography.bodySmall
                )
                LazyColumn(Modifier.weight(1f)) {
                    itemsIndexed(g) { i, members ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = checked.getOrElse(i) { false },
                                    onCheckedChange = { if (i < checked.size) checked[i] = it }
                                )
                                Column(Modifier.padding(end = 12.dp, top = 8.dp, bottom = 8.dp)) {
                                    members.forEach { m ->
                                        Text(
                                            m.name.ifBlank { "(no name)" } + "  " +
                                                m.phones.joinToString(", "),
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Button(
                    onClick = { confirm = true },
                    enabled = !busy && checked.any { it },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                ) { Text("Merge selected (${checked.count { it }})") }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Merge duplicates?") },
            text = {
                Text(
                    "A safety backup of all your contacts is saved first (see the Restore tab). " +
                        "In each selected group, numbers and emails are combined into one contact " +
                        "and the extra copies are deleted."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    val selected = (groups ?: emptyList()).filterIndexed { i, _ ->
                        checked.getOrElse(i) { false }
                    }
                    scope.launch {
                        busy = true
                        val merged = withContext(Dispatchers.IO) {
                            try {
                                BackupStore.createLocalBackup(ctx, "before_merge")
                                var ok = 0
                                selected.forEach { grp ->
                                    if (ContactsRepo.mergeGroup(ctx, grp)) ok++
                                }
                                ok
                            } catch (e: Exception) {
                                -1
                            }
                        }
                        busy = false
                        snack.showSnackbar(
                            if (merged >= 0) "$merged groups merged" else "Something went wrong, nothing was changed"
                        )
                        scan()
                    }
                }) { Text("Merge") }
            },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
        )
    }
}
