package com.aio.backup

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AioTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFF90CAF9), onPrimary = Color(0xFF002E5C))
    } else {
        lightColorScheme(primary = Color(0xFF1565C0))
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
